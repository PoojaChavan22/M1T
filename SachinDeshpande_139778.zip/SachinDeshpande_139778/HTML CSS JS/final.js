function displ()
{
var firstname=document.getElementById("fname").value;
var lastname=document.getElementById("lname").value;
var title=document.getElementById("title").value;


if(title=="none")
{
	alert("Please select the appropriate title");
}
else
{
	alert("All data for "+title+" "+firstname+" "+lastname+" entered successfully");
}
}